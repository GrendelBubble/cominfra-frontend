import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import client from '../lib/apollo-client';
import { VIEWER_QUERY } from '../graphql/queries/viewer';
import { LIST_CATEGORIES } from '../graphql/queries/categories';
import { LIST_POSTS } from '../graphql/queries/posts';
import Cookies from 'js-cookie';

function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [categories, setCategories] = useState<string[]>([]);
  const [posts, setPosts] = useState<{ title: string; author: string }[]>([]);

  const fetchData = async () => {
    const token = Cookies.get('token');
    if (token) {
      try {
        const viewerResponse = await client.query({
          query: VIEWER_QUERY,
          context: { headers: { Authorization: `Bearer ${token}` } },
        });
        setCurrentUser(viewerResponse.data.viewer);
        setIsLoggedIn(true);
      } catch {
        setIsLoggedIn(false);
      }
    }

    const categoriesResponse = await client.query({ query: LIST_CATEGORIES });
    setCategories(categoriesResponse.data.categories.nodes.map((cat: { name: string }) => cat.name));

    const postsResponse = await client.query({ query: LIST_POSTS });
    setPosts(postsResponse.data.posts.nodes.map((post: { title: string; author: { node: { name: string } } }) => ({
      title: post.title,
      author: post.author?.node?.name || 'Auteur inconnu',
    })));
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleLogout = () => {
    Cookies.remove('token');
    setIsLoggedIn(false);
    setCurrentUser(null);
  };

  return (
    <div>
      <Header
        categories={categories}
        isLoggedIn={isLoggedIn}
        currentUser={currentUser}
        onLogout={handleLogout}
      />
      <main className="main">
        <section>
          {posts.length > 0 ? (
            <ul className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {posts.map((post, index) => (
                <li key={index} className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
                  <h3 className="text-2xl font-semibold text-gray-900 mb-2">{post.title}</h3>
                  <p className="text-gray-600">Auteur : {post.author}</p>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-center text-gray-500">Aucune publication</p>
          )}
        </section>
      </main>
    </div>
  );
}

export default Home;
